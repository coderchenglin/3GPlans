//
//  ColoringSchemeViewController.m
//  ColoringScheme
//
//  Created by chenglin on 2024/3/22.
//

#import "ColoringSchemeViewController.h"
#import "ColoringSchemeView.h"
#import "ColorModel.h"
#import "Manager.h"

@interface ColoringSchemeViewController ()
@property (nonatomic, strong) ColoringSchemeView *coloringSchemeView;


@end

@implementation ColoringSchemeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    self.coloringSchemeView = [[ColoringSchemeView alloc] initWithFrame:self.view.frame];
    [self.view addSubview:self.coloringSchemeView];
    
    [self.coloringSchemeView viewInit];
    
    [self getColorModel];
    
}

- (void)getColorModel {
    
    [[Manager sharedManager] requestColoringScheme:@"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb0lkIjoxLCJleHAiOjE3MTEyMTMyODIsImlhdCI6MTcxMTE3MDA4MiwiaXNzIjoi5bCP6LW1Iiwic3ViIjoiY29sb3IifQ.eBgEy7peWXc_C8QIEz3hgzGkZnk_iDDoo8613MCUdLY" success:^(ColorModel * _Nonnull colorModel) {
        
        //这里有个理解，Model本身，一定是一个字典，只是，你拿到什么数据，取决于你Model中定义了哪些属性，所以先转为字典
        NSDictionary *dict = [colorModel toDictionary];
//        NSLog(@"%@,%d",colorModel,__LINE__);
        //然后这个字典里只有数组data
        NSArray* array = dict[@"data"];
//        NSLog(@"%@", array);
//        for (NSDictionary* dic in array) {
//            NSLog(@"%@", dic);
//        }
        
        
        dispatch_async(dispatch_get_main_queue(), ^{
//            [self.coloringSchemeView updateViewWithDic:array];
            [self.coloringSchemeView updateViewWithRGBArray: array];
            [self.coloringSchemeView updateCollectionViewWithRGBArray: array andIndex: self.coloringSchemeView.tableViewCellIndex];
        });
        
    } failure:^(NSError * _Nonnull error) {
        if (error)
            NSLog(@"网络连接失败");
    }];
        
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
