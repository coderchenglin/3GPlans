//
//  ColoringSchemeViewController.h
//  ColoringScheme
//
//  Created by chenglin on 2024/3/22.
//

#import <UIKit/UIKit.h>
#import "ColorModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ColoringSchemeViewController : UIViewController

@property (nonatomic, strong) ColorModel *getJSONModel;
@property (nonatomic, strong) NSDictionary *dictionaryModel;



@end

NS_ASSUME_NONNULL_END
