//
//  ColorModel.m
//  ColoringScheme
//
//  Created by chenglin on 2024/3/22.
//

#import "ColorModel.h"

//@implementation RGBAModel
//
//+ (BOOL)propertyIsOptional:(NSString *)propertyName {
//    return YES;
//}
//
//@end

@implementation ColorModel

+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end


