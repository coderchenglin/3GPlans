//
//  ColorTestModel.h
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/25.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface ColorTestModel : JSONModel

//@property (nonatomic, copy) NSDictionary *data;
@property (nonatomic, copy) NSArray *data;

@end

NS_ASSUME_NONNULL_END
