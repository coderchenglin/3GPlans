//
//  ColorTestModel.m
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/25.
//

#import "ColorTestModel.h"

@implementation ColorTestModel

+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end
