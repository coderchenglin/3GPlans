//
//  OptionModel.m
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/27.
//

#import "OptionModel.h"

@implementation OptionModel

+ (BOOL)propertyIsOptional:(NSString *)propertyName {
    return YES;
}

@end

