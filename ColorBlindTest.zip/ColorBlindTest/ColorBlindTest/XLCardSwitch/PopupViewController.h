//
//  PopupViewController.h
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PopupViewController : UIViewController

@property (nonatomic, strong) NSArray *dataSourceArray;

@end

NS_ASSUME_NONNULL_END
