//
//  RootViewController.h
//  FLAnimatedImageDemo
//
//  Created by Raphael Schaad on 4/1/14.
//  Copyright (c) Flipboard. All rights reserved.
//


#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController

@end
