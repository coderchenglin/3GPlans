//
//  SceneDelegate.h
//  PopoverControllerDemo
//
//  Created by chenglin on 2024/2/18.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

