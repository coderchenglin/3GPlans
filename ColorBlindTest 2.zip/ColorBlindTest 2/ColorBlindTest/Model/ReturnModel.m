//
//  ReturnModel.m
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/28.
//

#import "ReturnModel.h"

@implementation ReturnModel

@end
