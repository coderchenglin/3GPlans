//
//  OptionModel.h
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/27.
//

#import "JSONModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface OptionModel : JSONModel

@property (nonatomic, strong) NSArray *data;

@end

NS_ASSUME_NONNULL_END
