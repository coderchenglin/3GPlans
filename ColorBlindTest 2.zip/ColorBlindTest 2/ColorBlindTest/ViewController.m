//
//  ViewController.m
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/24.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
