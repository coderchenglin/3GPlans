//
//  SceneDelegate.h
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/24.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

