//
//  XLCardModel.m
//  ColorBlindTest
//
//  Created by chenglin on 2024/3/24.
//

#import "XLCardModel.h"

@implementation XLCardModel

@end
