//
//  XLPageSegmentedTitleView.h
//  ColorBlindArticle
//
//  Created by chenglin on 2024/4/2.
//

#import "XLPageBasicTitleView.h"

NS_ASSUME_NONNULL_BEGIN

@interface XLPageSegmentedTitleView : XLPageBasicTitleView

@end

NS_ASSUME_NONNULL_END
