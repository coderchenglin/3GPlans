//
//  CommonTableViewController.h
//  ColorBlindArticle
//
//  Created by chenglin on 2024/4/3.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VideoTableViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
