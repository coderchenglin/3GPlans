//
//  AppDelegate.h
//  ColorBlindArticle
//
//  Created by chenglin on 2024/3/29.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

